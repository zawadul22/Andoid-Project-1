package com.example.kharao;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final String [] locations = new String[]{"Mirpur","Jatrabari","Gulistan","Mohakhali"};
    public Button searchButton;
    public TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchButton = (Button) findViewById(R.id.searchID);
        textView = (TextView) findViewById(R.id.textID);

        AutoCompleteTextView edit1 = findViewById(R.id.fromid);
        AutoCompleteTextView edit2 = findViewById(R.id.toid);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, locations);
        edit1.setAdapter(adapter);
        edit2.setAdapter(adapter);

    }
    public void showMessage(View v){

        textView.setText("x");
    }


}
